# Decentralized Land Registration

Blockchain based Land Registration and transfer of entitlement system where the land ownership and all its details are stored in the Blockchain with zero chances of forgery in ownership.

Tools used:
1. React.js used for front-end development.
2. Solidity used for back-end development.
3. Truffle and Web3.js
4. Ganache used as a local blockchain.
5. Metamask wallet.

